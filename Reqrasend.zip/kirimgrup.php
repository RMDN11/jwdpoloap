<?php
session_start();
require_once 'config.php';
require_once 'auth_checkwa.php';

function kirimPesanGrupCanggih($groupId, $message, $imagePath, $apiUrl, $apiToken, $conn) {
    
    // Default endpoint: /api/v1/messages
    $textApiUrl = $apiUrl;
    $mediaApiUrl = $apiUrl;
    $returnPayload = ['sent_message' => $message];

    // JIKA MENGIRIM GAMBAR: Gunakan metode multipart/form-data
    if ($imagePath && $imagePath['error'] == UPLOAD_ERR_OK) {
        
        // Coba sesuaikan endpoint media, karena banyak API menggunakan endpoint berbeda untuk multipart.
        if (strpos($apiUrl, '/v1/messages') !== false) {
            // Coba ganti ke /api/message jika format API-nya seperti itu
            $mediaApiUrl = str_replace('/v1/messages', '/message', $apiUrl);
        } else {
            // Jika format API tidak standar, coba path /message
            $mediaApiUrl = rtrim($apiUrl, '/') . '/message';
        }

        // TRAYEK MULTI-PART (Lebih stabil untuk file biner)
        // Kita menggunakan field 'phone' untuk Grup ID, mengikuti konvensi Legacy API.
        $cfile = new CURLFile($imagePath['tmp_name'], $imagePath['type'], $imagePath['name']);
        $postData = [
            'type' => 'image', 
            'phone' => $groupId, // Menggunakan 'phone' sebagai ganti 'to' untuk kompatibilitas Legacy
            'message' => $message, 
            'attachment' => $cfile
        ];
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $mediaApiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $apiToken],
            CURLOPT_TIMEOUT => 30, // Tambahkan timeout
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            $returnPayload['status'] = 'GAGAL';
            $returnPayload['message'] = "cURL Error (Media Multi-Part): " . $curlError;
            return $returnPayload;
        }
        $responseData = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300) {
            $returnPayload['status'] = 'TERKIRIM';
            $returnPayload['message'] = "Pesan media (Multi-Part) berhasil dikirim.";
        } else {
            $errorMessage = isset($responseData['message']) ? $responseData['message'] : "Unknown error.";
            $returnPayload['status'] = 'GAGAL';
            $returnPayload['message'] = "Gagal (Media Multi-Part). Code: {$httpCode}. Pesan API: " . $errorMessage . " Response Penuh: " . substr($response, 0, 100);
        }
        return $returnPayload;

    // JIKA HANYA MENGIRIM TEKS: Gunakan metode JSON
    } else {
        $payload = [
            'recipient_type' => 'group',
            'to' => $groupId,
            'type' => 'text',
            'text' => ['body' => $message]
        ];

        $jsonData = json_encode($payload);
        $ch = curl_init($textApiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $jsonData,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $apiToken],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            $returnPayload['status'] = 'GAGAL';
            $returnPayload['message'] = "cURL Error (Teks): " . $curlError;
            return $returnPayload;
        }
        $responseData = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300) {
            $returnPayload['status'] = 'TERKIRIM';
            $returnPayload['message'] = "Pesan teks berhasil dikirim.";
        } else {
            $errorMessage = isset($responseData['message']) ? $responseData['message'] : "Unknown error.";
            $returnPayload['status'] = 'GAGAL';
            $returnPayload['message'] = "Gagal (Teks). Code: {$httpCode}. Pesan API: " . $errorMessage . " Response Penuh: " . substr($response, 0, 100);
        }
        return $returnPayload;
    }
}

// =================================================================
// PROSES FORM & LOGIKA HALAMAN
// =================================================================

$notification = '';
$notificationType = '';
if (isset($_SESSION['notification'])) {
    $notification = $_SESSION['notification'];
    $notificationType = $_SESSION['notification_type'];
    unset($_SESSION['notification']);
    unset($_SESSION['notification_type']);
}

// PROSES HAPUS SEMUA RIWAYAT PENGIRIMAN
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_history'])) {
    if ($conn->query("DELETE FROM log_wa WHERE message LIKE '%[GRUP]%'")) {
        $_SESSION['notification'] = "Semua riwayat pengiriman grup berhasil dihapus.";
        $_SESSION['notification_type'] = 'success';
    } else {
        $_SESSION['notification'] = "Gagal menghapus riwayat: " . $conn->error;
        $_SESSION['notification_type'] = 'error';
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// PROSES HAPUS RIWAYAT ISI PESAN
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_message_history'])) {
    // Menghapus log yang berisi konten pesan unik
    if ($conn->query("DELETE FROM log_wa WHERE message LIKE '%[GRUP]%'")) {
        $_SESSION['notification'] = "Semua riwayat isi pesan berhasil dihapus.";
        $_SESSION['notification_type'] = 'success';
    } else {
        $_SESSION['notification'] = "Gagal menghapus riwayat isi pesan: " . $conn->error;
        $_SESSION['notification_type'] = 'error';
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// PROSES HAPUS SATU RIWAYAT
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_log_id'])) {
    $logIdToDelete = $_POST['delete_log_id'];
    $stmt = $conn->prepare("DELETE FROM log_wa WHERE id = ? AND message LIKE '%[GRUP]%'");
    $stmt->bind_param("i", $logIdToDelete);
    if ($stmt->execute()) {
        $_SESSION['notification'] = "Satu riwayat pengiriman berhasil dihapus.";
        $_SESSION['notification_type'] = 'success';
    } else {
        $_SESSION['notification'] = "Gagal menghapus riwayat: " . $stmt->error;
        $_SESSION['notification_type'] = 'error';
    }
    $stmt->close();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}


// PROSES PENGIRIMAN PESAN
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['kirim_grup'])) {
    $selectedGroupIds = $_POST['selected_groups'] ?? [];
    $pesan = trim($_POST['pesan']);
    // Pastikan gambar valid untuk diunggah
    $imageFile = (isset($_FILES['promo_image']) && $_FILES['promo_image']['error'] == UPLOAD_ERR_OK) ? $_FILES['promo_image'] : null;
    
    if (empty($selectedGroupIds)) {
        $_SESSION['notification'] = "Gagal! Anda belum memilih grup penerima.";
        $_SESSION['notification_type'] = 'error';
    } elseif (empty($pesan) && !$imageFile) {
        $_SESSION['notification'] = "Gagal! Isi pesan atau gambar tidak boleh kosong.";
        $_SESSION['notification_type'] = 'error';
    } else {
        $berhasilTerkirim = 0; $gagalTerkirim = 0;
        $stmt = $conn->prepare("INSERT INTO log_wa (nowa, nama, message) VALUES (?, ?, ?)");

        foreach ($selectedGroupIds as $groupId) {
            $namaGrupLog = "Grup ID: " . $groupId;
            $namaResult = $conn->query("SELECT nama_grup FROM wa_grup WHERE id_grup = '{$conn->real_escape_string($groupId)}'");
            if($namaRow = $namaResult->fetch_assoc()) $namaGrupLog = $namaRow['nama_grup'];
            
            $result = kirimPesanGrupCanggih($groupId, $pesan, $imageFile, $apiUrl, $apiToken, $conn);
            
            $logMessage = "[" . $result['status'] . "] [GRUP] " . $result['message'];
            if ($imageFile) $logMessage .= " (dengan gambar)";
            $logMessage .= " :: " . $result['sent_message']; // Separator untuk menyimpan konten

            // Batasi panjang pesan log jika terlalu panjang agar tidak merusak database
            $logMessage = substr($logMessage, 0, 500); 

            $stmt->bind_param("sss", $groupId, $namaGrupLog, $logMessage);
            $stmt->execute();

            if ($result['status'] == 'TERKIRIM') $berhasilTerkirim++; else $gagalTerkirim++;
        }
        $stmt->close();
        $_SESSION['notification'] = "Pengiriman selesai. Berhasil: $berhasilTerkirim, Gagal: $gagalTerkirim.";
        $_SESSION['notification_type'] = $gagalTerkirim > 0 ? 'error' : 'success';
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}


// Ambil data grup dari DB untuk ditampilkan di form
$groupsByCategory = [];
$groupResult = $conn->query("SELECT id, nama_grup, id_grup, kategori FROM wa_grup ORDER BY kategori, nama_grup");
if ($groupResult) {
    while ($row = $groupResult->fetch_assoc()) {
        $groupsByCategory[$row['kategori']][] = $row;
    }
}

// Ambil data log untuk ditampilkan
$logPesan = [];
$logResult = $conn->query("SELECT id, nama, message, created_at FROM log_wa WHERE message LIKE '%[GRUP]%' ORDER BY created_at DESC LIMIT 30");
if($logResult) $logPesan = $logResult->fetch_all(MYSQLI_ASSOC);

// Ambil data riwayat isi pesan (unik)
$pesanHistory = [];
$historyResult = $conn->query("SELECT SUBSTRING_INDEX(message, ' :: ', -1) as sent_content FROM log_wa WHERE message LIKE '%[GRUP]%' GROUP BY sent_content ORDER BY MAX(id) DESC LIMIT 15");
if ($historyResult) {
    $pesanHistory = $historyResult->fetch_all(MYSQLI_ASSOC);
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kirim Pesan Grup - JWD</title>
  <?php $cache_buster = time(); ?>
<!-- MENGHILANGKAN GARIS MIRING AWAL UNTUK MENGUJI PATH RELATIF -->
<link rel="icon" href="LOGOJWD.png?v=<?= $cache_buster ?>" type="image/png">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    body { font-family: 'Inter', sans-serif; }
    .whatsapp-chat-preview { background-image: url('https://i.ibb.co/7z3P8sW/wa-bg.png'); }
    .chat-bubble { max-width: 80%; }
    /* Warna Abu-abu Modern */
    .bg-primary { background-color: #374151; } /* gray-800 */
    .bg-secondary { background-color: #4b5563; } /* gray-700 */
    .bg-card { background-color: #f3f4f6; } /* gray-100 */
    .text-primary { color: #111827; } /* gray-900 */
    .text-secondary { color: #4b5563; } /* gray-700 */
    .border-card { border-color: #e5e7eb; } /* gray-200 */
    .bg-accent { background-color: #9ca3af; } /* gray-400 */
    .text-accent { color: #9ca3af; } /* gray-400 */
    .bg-accent-light { background-color: #e5e7eb; } /* gray-200 */
    .text-accent-light { color: #9ca3af; } /* gray-400 */
    .bg-success { background-color: #d1fae5; } /* green-100 */
    .text-success { color: #065f46; } /* green-800 */
    .bg-error { background-color: #fee2e2; } /* red-100 */
    .text-error { color: #991b1b; } /* red-800 */
    .border-success { border-color: #a7f3d0; } /* green-300 */
    .border-error { border-color: #fecaca; } /* red-300 */
    .btn-primary { background: linear-gradient(to right, #6b7280, #4b5563); } /* gray-600 to gray-700 */
    .btn-primary:hover { background: linear-gradient(to right, #4b5563, #374151); } /* gray-700 to gray-800 */
    .btn-accent { background: linear-gradient(to right, #9ca3af, #6b7280); } /* gray-400 to gray-600 */
    .btn-accent:hover { background: linear-gradient(to right, #6b7280, #4b5563); } /* gray-600 to gray-700 */
    .badge-lunas { background-color: #d1fae5; color: #065f46; }
    .badge-belum-lunas { background-color: #fee2e2; color: #991b1b; }
    .badge-proses { background-color: #fef3c7; color: #92400e; }
    .badge-selesai { background-color: #d1fae5; color: #065f46; }
    .status-indicator { width: 0.5rem; height: 0.5rem; border-radius: 50%; }
    .status-proses { background-color: #f59e0b; } /* amber-500 */
    .status-selesai { background-color: #10b981; } /* emerald-500 */
    .preview-container { max-height: 200px; overflow-y: auto; }
    .preview-item { display: flex; justify-content: space-between; align-items: center; padding: 0.25rem 0.5rem; border-bottom: 1px solid #e5e7eb; }
    .preview-item:last-child { border-bottom: none; }
  </style>
</head>
<body class="bg-gray-50 text-gray-800">
  <div id="app" class="flex flex-col min-h-screen">
    <!-- Header Mobile Friendly -->
    <header class="bg-gray-800 text-white shadow-sm sticky top-0 z-10">
        <div class="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3">
            <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
                <div class="flex items-center space-x-3">
                    <div class="bg-gradient-to-br from-gray-600 to-gray-700 p-2 sm:p-3 rounded-xl shadow-lg">
                        <i class="fas fa-users text-white text-xl sm:text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-lg sm:text-xl font-bold text-white">Kirim Pesan Grup</h1>
                        <p class="text-xs sm:text-sm text-gray-300">Atur Promosi Ke Grup WhatsApp</p>
                    </div>
                </div>
                <!-- Tombol Navigasi - Stack on mobile -->
                <div class="flex flex-wrap gap-2 justify-center sm:justify-start">
                    <a href="reminder.php" class="text-xs sm:text-sm font-medium text-gray-300 hover:text-white px-2 py-1 rounded bg-gray-700 bg-opacity-50">
                        <i class="fas fa-bell mr-1"></i> Pembayaran
                    </a>
                    <a href="promosi.php" class="text-xs sm:text-sm font-medium text-gray-300 hover:text-white px-2 py-1 rounded bg-gray-700 bg-opacity-50">
                        <i class="fas fa-bullhorn mr-1"></i> Promosi 
                    </a>
                    <a href="kelola_reminder.php" class="text-xs sm:text-sm font-medium text-gray-300 hover:text-white px-2 py-1 rounded bg-gray-700 bg-opacity-50">
                        <i class="fas fa-message mr-1"></i> Reminder Peserta
                    </a>
					<a href="kelola_grup.php" class="text-xs sm:text-sm font-medium text-gray-300 hover:text-white px-2 py-1 rounded bg-gray-700 bg-opacity-50">
                        <i class="fas fa-plus-circle mr-1"></i> Tambah Grup
                    </a>
                    <a href="logoutwa.php" class="text-xs sm:text-sm font-medium text-gray-300 hover:text-white px-2 py-1 rounded bg-gray-700 bg-opacity-50">
                        <i class="fas fa-right-from-bracket"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
    </header>


    <main class="flex-grow p-4 sm:p-6 lg:p-8">
      <div class="max-w-7xl mx-auto">
        <?php if (!empty($notification)): ?>
        <div class="mb-6 p-4 rounded-lg shadow-md <?php echo $notificationType === 'success' ? 'bg-success text-success border-l-4 border-success' : 'bg-error text-error border-l-4 border-error'; ?>"><?php echo htmlspecialchars($notification); ?></div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <!-- Kolom Kiri: Panel Pengiriman -->
            <div class="space-y-6">
                <form method="POST" action="" enctype="multipart/form-data" id="main-form">
                    <div class="bg-card shadow-md rounded-2xl p-6 border border-card">
                        <h2 class="text-lg font-semibold mb-4 flex items-center text-primary"><i class="fas fa-pencil-alt text-xl mr-2 text-accent"></i> Buat Pesan Anda</h2>
                        <div class="space-y-4">
                            <div>
                                <label for="pesan" class="block font-semibold text-sm text-gray-700 mb-1">Isi Pesan / Caption</label>
                                <textarea id="pesan" name="pesan" rows="8" class="w-full border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-400 text-sm transition bg-white" placeholder="Tulis pesan Anda di sini..."></textarea>
                            </div>
                            <div>
                                <label for="promo_image" class="block font-semibold text-sm text-gray-700 mb-1">Upload Gambar (Opsional)</label>
                                <input type="file" id="promo_image" name="promo_image" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer" accept="image/png, image/jpeg, image/gif">
                            </div>
                            <div class="border-t pt-4">
                                <h2 class="text-lg font-semibold mb-4 flex items-center text-primary"><i class="fas fa-check-square text-xl mr-2 text-accent"></i> Pilih Grup Penerima</h2>
                                <div class="relative">
                                    <button type="button" id="group-filter-btn" class="w-full bg-white border border-gray-300 rounded-lg p-2.5 text-left flex justify-between items-center focus:ring-2 focus:ring-blue-400 transition">
                                        <span id="group-filter-btn-text">Pilih Grup Penerima</span>
                                        <i class="fas fa-caret-down"></i>
                                    </button>
                                    <div id="group-filter-popup" class="hidden absolute z-20 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto p-2">
                                        <?php if (!empty($groupsByCategory)): ?>
                                            <?php foreach($groupsByCategory as $kategori => $groups): ?>
                                            <div class="category-group space-y-1 mb-2">
                                                <label class="flex items-center space-x-3 cursor-pointer p-2 border-b">
                                                    <input type="checkbox" class="category-checkbox h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                                    <span class="text-sm font-semibold text-gray-700"><?= htmlspecialchars($kategori) ?></span>
                                                </label>
                                                <div class="pl-4 pt-1">
                                                    <?php foreach($groups as $group): ?>
                                                    <label class="flex items-center space-x-3 cursor-pointer p-1.5 rounded-md hover:bg-gray-50">
                                                        <input type="checkbox" name="selected_groups[]" value="<?= htmlspecialchars($group['id_grup']) ?>" class="group-checkbox h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                                        <span class="text-sm text-gray-700"><?= htmlspecialchars($group['nama_grup']) ?></span>
                                                    </label>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <p class="text-sm text-gray-500 text-center p-8">Belum ada grup. <a href="kelola_grup.php" class="text-blue-600 font-semibold hover:underline">Tambah Grup</a></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="border-t pt-4">
                                <button type="submit" name="kirim_grup" class="w-full btn-primary text-white px-6 py-3 rounded-lg shadow-lg font-bold text-lg transition flex items-center justify-center transform hover:scale-105">
                                    <i class="fas fa-paper-plane text-2xl mr-2"></i> Kirim Pesan
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- Kolom Kanan: Preview -->
            <div class="space-y-6 lg:sticky top-24">
                 <div class="bg-card shadow-md rounded-2xl p-6 border border-card">
                     <h2 class="text-lg font-semibold mb-4 flex items-center text-primary"><i class="fas fa-mobile-alt text-xl mr-2 text-accent"></i> Preview Chat</h2>
                     <div class="w-full max-w-sm mx-auto bg-white rounded-2xl shadow-lg overflow-hidden border">
                         <div class="whatsapp-chat-preview p-4 h-96 flex flex-col-reverse overflow-y-auto">
                            <div id="chat-preview-container" class="flex flex-col items-end space-y-2">
                                <!-- Preview Bubble akan muncul di sini -->
                            </div>
                         </div>
                     </div>
                </div>
            </div>
        </div>

        <!-- Bagian Riwayat di bawah -->
        <div class="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <!-- Kolom Riwayat Isi Pesan -->
            <div class="bg-card shadow-md rounded-2xl p-6 border border-card">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg font-semibold flex items-center text-primary"><i class="fas fa-comment-dots text-xl mr-2 text-accent"></i> Riwayat Isi Pesan</h2>
                    <form method="POST" onsubmit="return confirm('Anda yakin ingin menghapus semua riwayat isi pesan? Ini juga akan menghapus log pengiriman terkait.');" class="inline-block">
                        <button type="submit" name="delete_message_history" class="text-xs bg-red-100 text-red-700 font-semibold px-3 py-1.5 rounded-lg hover:bg-red-200 transition flex items-center">
                            <i class="fas fa-trash text-sm mr-1.5"></i>
                            Hapus Semua
                        </button>
                    </form>
                </div>
                <div class="space-y-2 max-h-96 overflow-y-auto pr-2">
                     <?php if(!empty($pesanHistory)): ?>
                        <?php foreach($pesanHistory as $history): ?>
                            <button type="button" class="use-again-btn w-full text-left text-sm p-3 bg-gray-50 rounded-lg border hover:bg-blue-50 hover:border-blue-300 transition" data-message="<?= htmlspecialchars($history['sent_content']) ?>">
                                <p class="truncate text-gray-700"><?= htmlspecialchars($history['sent_content']) ?></p>
                            </button>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 text-center p-8">Belum ada riwayat isi pesan.</p>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Kolom Riwayat Pengiriman -->
            <div class="bg-card shadow-md rounded-2xl p-6 border border-card">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg font-semibold flex items-center text-primary"><i class="fas fa-history text-xl mr-2 text-accent"></i> Riwayat Pengiriman</h2>
                    <form method="POST" onsubmit="return confirm('Anda yakin ingin menghapus semua riwayat pengiriman grup?');" class="inline-block">
                        <button type="submit" name="delete_history" class="text-xs bg-red-100 text-red-700 font-semibold px-3 py-1.5 rounded-lg hover:bg-red-200 transition flex items-center">
                            <i class="fas fa-trash text-sm mr-1.5"></i>
                            Hapus Semua
                        </button>
                    </form>
                </div>
                <div class="space-y-3 max-h-96 overflow-y-auto pr-2">
                    <?php if(!empty($logPesan)): ?>
                        <?php foreach($logPesan as $log): ?>
                            <?php
                            $logParts = explode(' :: ', $log['message'], 2);
                            $statusMessage = $logParts[0];
                            $sentContent = isset($logParts[1]) ? $logParts[1] : '';
                            $isSuccess = strpos($statusMessage, '[TERKIRIM]') !== false;
                            ?>
                            <div class="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg border">
                                <div><?php if ($isSuccess): ?><i class="fas fa-check-circle text-green-500 text-xl mt-1"></i><?php else: ?><i class="fas fa-times-circle text-red-500 text-xl mt-1"></i><?php endif; ?></div>
                                <div class="flex-1 overflow-hidden">
                                    <p class="font-semibold text-gray-800 text-sm truncate"><?= htmlspecialchars($log['nama']) ?></p>
                                    <p class="text-xs text-gray-500 mt-1"><?= htmlspecialchars($statusMessage) ?></p>
                                    <div class="flex justify-between items-center mt-2">
                                        <p class="text-gray-400 text-[10px]"><?= date('d M Y, H:i', strtotime($log['created_at'])) ?></p>
                                        <form method="POST" onsubmit="return confirm('Anda yakin ingin menghapus riwayat ini?');" class="inline-block">
                                            <input type="hidden" name="delete_log_id" value="<?= $log['id'] ?>">
                                            <button type="submit" class="text-gray-400 hover:text-red-500" title="Hapus riwayat ini">
                                                <i class="fas fa-trash text-sm"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 text-center p-8">Belum ada riwayat.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
      </div>
    </main>
  </div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const pesanTextarea = document.getElementById('pesan');

    // Dropdown Grup
    const groupBtn = document.getElementById('group-filter-btn');
    const groupPopup = document.getElementById('group-filter-popup');
    const groupBtnText = document.getElementById('group-filter-btn-text');

    if (groupBtn) {
        groupBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            groupPopup.classList.toggle('hidden');
        });

        document.addEventListener('click', (e) => {
            if (!groupPopup.contains(e.target) && !groupBtn.contains(e.target)) {
                groupPopup.classList.add('hidden');
            }
        });

        document.querySelectorAll('.category-checkbox').forEach(hcb => {
            hcb.addEventListener('change', function() {
                const groupCheckboxes = this.closest('.category-group').querySelectorAll('.group-checkbox');
                groupCheckboxes.forEach(cb => { cb.checked = this.checked; });
                updateButtonText();
            });
        });

        document.querySelectorAll('.group-checkbox').forEach(cb => {
            cb.addEventListener('change', updateButtonText);
        });

        function updateButtonText() {
            const selectedCount = document.querySelectorAll('.group-checkbox:checked').length;
            if (selectedCount === 0) {
                groupBtnText.textContent = `Pilih Grup Penerima`;
            } else {
                groupBtnText.textContent = `${selectedCount} Grup Terpilih`;
            }
        }
        updateButtonText();
    }
    
    // Tombol Gunakan Lagi dari Riwayat Isi Pesan
    document.querySelectorAll('.use-again-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const message = this.dataset.message;
            pesanTextarea.value = message;
            pesanTextarea.dispatchEvent(new Event('input')); // Update preview
            window.scrollTo({ top: 0, behavior: 'smooth' }); // Scroll ke atas
        });
    });

    // Update Preview Real-time
    const imageInput = document.getElementById('promo_image');
    const previewContainer = document.getElementById('chat-preview-container');

    function renderPreviewMessage(text) {
        let previewText = text.replace(/(https?:\/\/[^\s]+)/g, '<a href="#" class="text-cyan-600 break-all">$1</a>');
        return previewText.replace(/\n/g, '<br>');
    }

    function updatePreview() {
        const messageText = pesanTextarea.value;
        const imageFile = imageInput.files[0];

        previewContainer.innerHTML = ''; // Kosongkan preview

        if (!messageText && !imageFile) return;

        const bubble = document.createElement('div');
        bubble.className = 'chat-bubble self-end bg-green-100 rounded-lg p-2 shadow-sm flex flex-col';
        
        let contentHTML = '';

        if(imageFile) {
            const reader = new FileReader();
            reader.onload = function(e) {
                let imgContainer = bubble.querySelector('#preview-image-container');
                if (imgContainer) {
                    imgContainer.innerHTML = `<img src="${e.target.result}" class="rounded-md max-h-40 w-auto">`;
                }
            }
            reader.readAsDataURL(imageFile);
            contentHTML += `<div id="preview-image-container" class="mb-1"></div>`;
        }

        if (messageText) {
            contentHTML += `<div class="text-sm text-gray-800 break-words">${renderPreviewMessage(messageText)}</div>`;
        }
        
        contentHTML += `<div class="text-right text-xs text-gray-400 mt-1">1:30 PM</div>`;
        bubble.innerHTML = contentHTML;

        previewContainer.appendChild(bubble);
    }
    
    pesanTextarea.addEventListener('input', updatePreview);
    imageInput.addEventListener('change', updatePreview);
    
    // Initial preview render
    updatePreview();
});
</script>
</body>
</html>