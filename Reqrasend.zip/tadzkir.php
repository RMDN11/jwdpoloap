<?php
require_once 'config.php';
$notification = '';
$notificationType = '';

// Ambil notifikasi dari session jika ada
if (isset($_SESSION)) {
    if (isset($_SESSION['notification'])) {
        $notification = $_SESSION['notification'];
        $notificationType = $_SESSION['notificationType'];
        unset($_SESSION['notification']);
        unset($_SESSION['notificationType']);
    }
} else {
    session_start();
    if (isset($_SESSION['notification'])) {
        $notification = $_SESSION['notification'];
        $notificationType = $_SESSION['notificationType'];
        unset($_SESSION['notification']);
        unset($_SESSION['notificationType']);
    }
}

// Ambil daftar Halaqoh
$halaqohList = [];
$halaqohResult = $conn->query("SELECT DISTINCT halaqoh FROM peserta WHERE halaqoh IS NOT NULL AND halaqoh != '' ORDER BY halaqoh");
while ($row = $halaqohResult->fetch_assoc()) {
    $halaqohList[] = $row['halaqoh'];
}

// Proses pengiriman akhir (saat tombol "Kirim Semua Permintaan" diklik)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_all_requests'])) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    $halaqoh = $_POST['halaqoh'] ?? '';
    $pesanPengajar = $_POST['pesan_pengajar'] ?? '';
    $selectedPeserta = json_decode($_POST['selected_peserta_json'], true);

    if (empty($halaqoh) || empty($selectedPeserta) || !is_array($selectedPeserta) || count($selectedPeserta) === 0) {
        $_SESSION['notification'] = "Gagal! Halaqoh dan setidaknya satu peserta harus dipilih.";
        $_SESSION['notificationType'] = 'error';
    } else {
        $success_count = 0;
        $error_count = 0;
        $errors = [];

        foreach ($selectedPeserta as $pesertaData) {
            $pesertaId = $pesertaData['id'];
            $pesertaNama = $pesertaData['nama'];
            $pesertaNowa = $pesertaData['nowa'];

            // Validasi data peserta (opsional, tapi disarankan)
            $stmt = $conn->prepare("SELECT id, nama_lengkap, nowa FROM peserta WHERE id = ? AND halaqoh = ?");
            $stmt->bind_param("is", $pesertaId, $halaqoh);
            $stmt->execute();
            $result = $stmt->get_result();
            $validPeserta = $result->fetch_assoc();
            $stmt->close();

            if ($validPeserta) {
                $stmt_insert = $conn->prepare("INSERT INTO reminder_requests (halaqoh, peserta_id, peserta_nama, peserta_nowa, pesan_pengajar) VALUES (?, ?, ?, ?, ?)");
                $stmt_insert->bind_param("sisss", $halaqoh, $validPeserta['id'], $validPeserta['nama_lengkap'], $validPeserta['nowa'], $pesanPengajar);
                if ($stmt_insert->execute()) {
                    $success_count++;
                } else {
                    $error_count++;
                    $errors[] = "Gagal menyimpan permintaan untuk " . htmlspecialchars($validPeserta['nama_lengkap']) . ": " . $stmt_insert->error;
                }
                $stmt_insert->close();
            } else {
                $error_count++;
                $errors[] = "Peserta tidak valid atau tidak termasuk dalam halaqoh yang dipilih: " . htmlspecialchars($pesertaNama);
            }
        }

        if ($success_count > 0) {
            $msg = "Berhasil! $success_count permintaan reminder telah dikirim ke admin.";
            if ($error_count > 0) {
                $msg .= " Namun, $error_count permintaan gagal.";
            }
            $_SESSION['notification'] = $msg;
            $_SESSION['notificationType'] = 'success';
        } else {
            $_SESSION['notification'] = "Gagal! Tidak ada permintaan yang berhasil dikirim.";
            $_SESSION['notificationType'] = 'error';
        }
        if (!empty($errors)) {
            // Tambahkan detail error ke session jika perlu, atau log
            error_log("Errors in form_reminder_modern: " . print_r($errors, true));
        }

        // Redirect untuk mencegah re-submit saat refresh
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Form Reminder - JWD</title>
  <?php $cache_buster = time(); ?>
  <link rel="icon" href="LOGOJWD.png?v=<?= $cache_buster ?>" type="image/png">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/phosphor-icons/1.4.2/css/phosphor.css" rel="stylesheet">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%);
    }
    #suggestions-list li:hover {
      background-color: #f1f5f9;
      transform: translateX(4px);
      transition: all 0.2s ease;
    }
    .card-3d {
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card-3d:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15), 0 10px 10px -6px rgba(0, 0, 0, 0.1);
    }
    .btn-gradient {
      background: linear-gradient(135deg, #6b7280, #4b5563);
    }
    .btn-gradient:hover {
      background: linear-gradient(135deg, #4b5563, #374151);
    }
    .btn-add-another {
      background: linear-gradient(135deg, #3b82f6, #2563eb);
    }
    .btn-add-another:hover {
      background: linear-gradient(135deg, #2563eb, #1d4ed8);
    }
    .btn-remove {
      background-color: #ef4444;
      color: white;
      padding: 0.25rem 0.5rem;
      border-radius: 0.25rem;
      cursor: pointer;
      font-size: 0.75rem;
    }
    .btn-remove:hover {
      background-color: #dc2626;
    }
    .input-shadow {
      box-shadow: inset 0 1px 2px rgba(0,0,0,0.05);
    }
    #selected-participants-list {
        max-height: 200px; /* Atur tinggi maksimum */
        overflow-y: auto;  /* Aktifkan scroll vertikal jika melebihi tinggi */
        margin-top: 0.5rem;
    }
    #selected-participants-list p {
        margin-bottom: 0.25rem;
    }
  </style>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">
  <div class="w-full max-w-2xl"> <!-- Lebar maksimum diperbesar -->
    <div class="bg-white rounded-2xl card-3d p-8">
        <div class="flex items-center space-x-4 mb-6">
            <div class="bg-gradient-to-br from-gray-600 to-gray-800 p-4 rounded-xl shadow-md">
                <i class="ph-bell-ringing text-white text-3xl"></i>
            </div>
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Pengingat untuk Peserta</h1>
                <p class="text-sm text-gray-500">Saling mengingatkan untuk kebaikan</p>
            </div>
        </div>

        <?php if (!empty($notification)): ?>
        <div class="mb-6 p-4 rounded-lg shadow-sm <?php echo $notificationType === 'success' ? 'bg-green-50 text-green-700 border-l-4 border-green-500' : 'bg-red-50 text-red-700 border-l-4 border-red-500'; ?>">
            <?php echo htmlspecialchars($notification); ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="" class="space-y-6" id="request-form">
            <div>
                <label for="halaqoh" class="block text-sm font-semibold text-gray-800 mb-2">Halaqoh</label>
                <select name="halaqoh" id="halaqoh" class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-transparent transition input-shadow" required>
                    <option value="" disabled selected>-- Pilih Halaqoh Anda --</option>
                    <?php foreach ($halaqohList as $halaqoh): ?>
                        <option value="<?= htmlspecialchars($halaqoh) ?>"><?= htmlspecialchars($halaqoh) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div id="peserta-section" class="hidden">
                <div class="relative mb-4">
                    <label for="search-peserta" class="block text-sm font-semibold text-gray-800 mb-2">Cari Nama Peserta dari Halaqoh Terpilih</label>
                    <input type="text" id="search-peserta" placeholder="Ketik nama untuk mencari..." class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-transparent transition input-shadow" autocomplete="off" disabled>
                    <div id="suggestions-list" class="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg hidden max-h-60 overflow-y-auto"></div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-800 mb-2">Peserta Terpilih:</label>
                    <div id="selected-participants-list" class="border border-gray-200 rounded-lg p-3 bg-gray-50">
                        <p class="text-gray-500 text-sm">Belum ada peserta dipilih.</p>
                    </div>
                </div>

                <div class="flex flex-wrap gap-2 mb-6">
                    <button type="button" id="add-another-btn" class="btn-add-another px-4 py-2 rounded-lg shadow-md hover:shadow-lg font-medium text-sm transition duration-300 flex items-center disabled:opacity-50" disabled>
                        <i class="ph-plus-bold text-sm mr-1"></i> Tambah Peserta Lainnya
                    </button>
                    <button type="button" id="remove-all-btn" class="bg-gray-500 text-white px-4 py-2 rounded-lg shadow-md hover:shadow-lg font-medium text-sm transition duration-300 flex items-center">
                        <i class="ph-trash text-sm mr-1"></i> Hapus Semua
                    </button>
                </div>
            </div>

            <div id="pesan-section" class="hidden">
                <div>
                    <label for="pesan-pengajar" class="block text-sm font-semibold text-gray-800 mb-2">Pesan Tambahan (Tidak Wajib)</label>
                    <textarea id="pesan-pengajar" name="pesan_pengajar" rows="4" placeholder="Contoh: Sudah 4 hari ga setoran" class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-transparent transition input-shadow"></textarea>
                </div>

                <input type="hidden" name="selected_peserta_json" id="selected-peserta-json" value="">
                <div>
                    <button type="submit" name="submit_all_requests" id="submit-all-btn" class="w-full btn-gradient text-white px-6 py-3 rounded-lg shadow-md hover:shadow-lg font-bold text-lg transition duration-300 flex items-center justify-center transform hover:scale-[1.02]" disabled>
                        <i class="ph-paper-plane-tilt text-xl mr-2"></i> Kirim Semua Permintaan
                    </button>
                </div>
            </div>
        </form>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        const halaqohSelect = document.getElementById('halaqoh');
        const pesertaSection = document.getElementById('peserta-section');
        const searchInput = document.getElementById('search-peserta');
        const suggestionsList = document.getElementById('suggestions-list');
        const selectedParticipantsList = document.getElementById('selected-participants-list');
        const addAnotherBtn = document.getElementById('add-another-btn');
        const removeAllBtn = document.getElementById('remove-all-btn');
        const submitAllBtn = document.getElementById('submit-all-btn');
        const pesanSection = document.getElementById('pesan-section');
        const selectedPesertaJsonInput = document.getElementById('selected-peserta-json');
        const requestForm = document.getElementById('request-form');

        let selectedParticipants = [];
        let searchTimeout;

        // Fungsi untuk memperbarui tampilan peserta terpilih
        function updateSelectedList() {
            selectedParticipantsList.innerHTML = ''; // Kosongkan dulu
            if (selectedParticipants.length === 0) {
                selectedParticipantsList.innerHTML = '<p class="text-gray-500 text-sm">Belum ada peserta dipilih.</p>';
                submitAllBtn.disabled = true;
                pesanSection.classList.add('hidden'); // Sembunyikan pesan dan tombol submit jika tidak ada peserta
            } else {
                selectedParticipants.forEach((peserta, index) => {
                    const p = document.createElement('p');
                    p.className = 'flex justify-between items-center bg-white p-2 rounded border';
                    p.innerHTML = `
                        <span>${peserta.nama} (${peserta.nowa || 'No. WA tidak ada'})</span>
                        <button type="button" class="btn-remove" data-index="${index}">X</button>
                    `;
                    selectedParticipantsList.appendChild(p);
                });
                submitAllBtn.disabled = false;
                pesanSection.classList.remove('hidden'); // Tampilkan pesan dan tombol submit jika ada peserta
            }
            // Update hidden input
            selectedPesertaJsonInput.value = JSON.stringify(selectedParticipants);
        }

        // Event listener untuk tombol Hapus Semua
        removeAllBtn.addEventListener('click', function() {
            selectedParticipants = [];
            updateSelectedList();
        });

        // Event delegation untuk tombol hapus individual
        selectedParticipantsList.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-remove')) {
                const index = parseInt(e.target.getAttribute('data-index'));
                if (!isNaN(index) && index >= 0 && index < selectedParticipants.length) {
                    selectedParticipants.splice(index, 1); // Hapus dari array
                    updateSelectedList(); // Perbarui tampilan
                }
            }
        });

        // Event listener untuk memilih Halaqoh
        halaqohSelect.addEventListener('change', function() {
            const selectedHalaqoh = this.value;
            if (selectedHalaqoh) {
                pesertaSection.classList.remove('hidden');
                searchInput.disabled = false;
                searchInput.value = ''; // Kosongkan input pencarian
                suggestionsList.innerHTML = '';
                suggestionsList.classList.add('hidden');
            } else {
                pesertaSection.classList.add('hidden');
                searchInput.disabled = true;
                selectedParticipants = [];
                updateSelectedList();
                pesanSection.classList.add('hidden');
            }
        });

        // Event listener untuk pencarian peserta
        searchInput.addEventListener('input', function() {
            const query = this.value.trim();
            const selectedHalaqoh = halaqohSelect.value; // Ambil halaqoh terpilih

            // Hapus pencarian sebelumnya yang tertunda
            clearTimeout(searchTimeout);

            // Sembunyikan saran jika query terlalu pendek atau halaqoh belum dipilih
            if (query.length < 2 || !selectedHalaqoh) {
                suggestionsList.innerHTML = '';
                suggestionsList.classList.add('hidden');
                return;
            }

            suggestionsList.innerHTML = '<p class="text-sm text-gray-500 p-4 text-center">Mencari...</p>';
            suggestionsList.classList.remove('hidden');

            // Tunda pencarian untuk menghindari permintaan berlebihan
            searchTimeout = setTimeout(() => {
                // Gunakan fetch untuk mencari peserta berdasarkan nama dan halaqoh
                fetch(`search_peserta.php?term=${encodeURIComponent(query)}&halaqoh=${encodeURIComponent(selectedHalaqoh)}`)
                    .then(response => response.ok ? response.json() : Promise.reject('Network error'))
                    .then(data => {
                        suggestionsList.innerHTML = '';
                        if (data.length > 0) {
                            const ul = document.createElement('ul');
                            ul.className = 'p-2';
                            data.forEach(peserta => {
                                // Cek apakah peserta sudah dipilih sebelumnya
                                const alreadySelected = selectedParticipants.some(p => p.id === peserta.id);
                                if (alreadySelected) return; // Lewati jika sudah dipilih

                                const li = document.createElement('li');
                                li.className = 'p-3 rounded-md cursor-pointer transition';
                                li.innerHTML = `<p class="font-semibold text-gray-800">${peserta.nama_lengkap}</p><p class="text-xs text-gray-500">${peserta.nowa || 'No. WA tidak ada'}</p>`;
                                li.dataset.id = peserta.id;
                                li.dataset.nama = peserta.nama_lengkap;
                                li.dataset.nowa = peserta.nowa || '';
                                ul.appendChild(li);
                            });
                            if (ul.children.length === 0) {
                                suggestionsList.innerHTML = '<p class="text-sm text-gray-500 p-4 text-center">Semua peserta dari halaqoh ini sudah dipilih.</p>';
                            } else {
                                suggestionsList.appendChild(ul);
                            }
                        } else {
                            suggestionsList.innerHTML = '<p class="text-sm text-gray-500 p-4 text-center">Tidak ditemukan peserta di halaqoh ini.</p>';
                        }
                        suggestionsList.classList.remove('hidden');
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        suggestionsList.innerHTML = '<p class="text-sm text-red-500 p-4 text-center">Gagal memuat data.</p>';
                    });
            }, 300);
        });

        // Event listener untuk memilih peserta dari daftar saran
        suggestionsList.addEventListener('click', function(e) {
            let target = e.target.closest('li');
            if (target) {
                const id = target.dataset.id;
                const nama = target.dataset.nama;
                const nowa = target.dataset.nowa;

                // Tambahkan ke array jika belum ada
                if (!selectedParticipants.some(p => p.id === id)) {
                    selectedParticipants.push({ id: id, nama: nama, nowa: nowa });
                    updateSelectedList();
                }

                // Kosongkan input pencarian dan sembunyikan saran
                searchInput.value = '';
                suggestionsList.innerHTML = '';
                suggestionsList.classList.add('hidden');
            }
        });

        // Sembunyikan saran jika klik di luar input atau daftar
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !suggestionsList.contains(e.target)) {
                suggestionsList.classList.add('hidden');
            }
        });

        // Event listener untuk tombol "Tambah Peserta Lainnya"
        addAnotherBtn.addEventListener('click', function() {
            // Fokus ke input pencarian
            searchInput.focus();
            // Sembunyikan tombol "Tambah Peserta Lainnya" sampai peserta dipilih lagi
            addAnotherBtn.disabled = true;
        });

        // Aktifkan tombol "Tambah Peserta Lainnya" ketika peserta dipilih
        // Ini bisa dilakukan saat updateSelectedList() dipanggil, jika jumlah peserta bertambah
        // Tapi karena updateSelectedList bisa dipanggil karena penghapusan juga,
        // kita gunakan event listener pada daftar saran saat dipilih.
        // Alternatif: aktifkan saat daftar saran muncul dan ada hasil.
        suggestionsList.addEventListener('DOMNodeInserted', function() {
             if (suggestionsList.children.length > 0 && suggestionsList.innerHTML.trim() !== '' && !suggestionsList.innerHTML.includes('Mencari...') && !suggestionsList.innerHTML.includes('Tidak ditemukan') && !suggestionsList.innerHTML.includes('Semua peserta')) {
                 addAnotherBtn.disabled = false;
             }
        });

        // Atau aktifkan setelah pencarian selesai dan ada hasil (lebih baik)
        searchInput.addEventListener('input', function() {
            // Kode pencarian di atas tetap ada
            clearTimeout(searchTimeout);
            const query = this.value.trim();
            const selectedHalaqoh = halaqohSelect.value;

            if (query.length < 2 || !selectedHalaqoh) {
                addAnotherBtn.disabled = (selectedParticipants.length === 0);
                return;
            }

            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                fetch(`search_peserta.php?term=${encodeURIComponent(query)}&halaqoh=${encodeURIComponent(selectedHalaqoh)}`)
                    .then(response => response.ok ? response.json() : Promise.reject('Network error'))
                    .then(data => {
                        suggestionsList.innerHTML = '';
                        if (data.length > 0) {
                            const ul = document.createElement('ul');
                            ul.className = 'p-2';
                            let hasSelectable = false; // Flag untuk mengecek apakah ada peserta yang bisa dipilih
                            data.forEach(peserta => {
                                const alreadySelected = selectedParticipants.some(p => p.id === peserta.id);
                                if (!alreadySelected) {
                                    const li = document.createElement('li');
                                    li.className = 'p-3 rounded-md cursor-pointer transition';
                                    li.innerHTML = `<p class="font-semibold text-gray-800">${peserta.nama_lengkap}</p><p class="text-xs text-gray-500">${peserta.nowa || 'No. WA tidak ada'}</p>`;
                                    li.dataset.id = peserta.id;
                                    li.dataset.nama = peserta.nama_lengkap;
                                    li.dataset.nowa = peserta.nowa || '';
                                    ul.appendChild(li);
                                    hasSelectable = true; // Set flag jika ada yang bisa dipilih
                                }
                            });
                            if (hasSelectable) {
                                suggestionsList.appendChild(ul);
                                addAnotherBtn.disabled = false; // Aktifkan tombol jika ada yang bisa dipilih
                            } else {
                                suggestionsList.innerHTML = '<p class="text-sm text-gray-500 p-4 text-center">Semua peserta dari halaqoh ini sudah dipilih.</p>';
                                // Biarkan tombol "Tambah Peserta Lainnya" aktif jika sudah ada peserta, tapi tidak bisa menambah lagi
                                // addAnotherBtn.disabled = true; // Opsional: nonaktifkan jika tidak bisa menambah lagi
                            }
                        } else {
                            suggestionsList.innerHTML = '<p class="text-sm text-gray-500 p-4 text-center">Tidak ditemukan peserta di halaqoh ini.</p>';
                        }
                        suggestionsList.classList.remove('hidden');
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        suggestionsList.innerHTML = '<p class="text-sm text-red-500 p-4 text-center">Gagal memuat data.</p>';
                    });
            }, 300);
        });

        // Awalnya, tombol "Tambah Peserta Lainnya" dinonaktifkan karena tidak ada peserta
        addAnotherBtn.disabled = true;

    });
  </script>
</body>
</html>