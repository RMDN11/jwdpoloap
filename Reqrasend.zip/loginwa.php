<?php
session_start();

// Debug mode untuk development
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php'; // Pastikan path ini benar

$error = '';
$success_message = '';

// Cek jika sudah login, redirect ke reminder.php
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: reminder.php");
    exit();
}

// Cek jika ada pesan logout
if (isset($_SESSION['logout_message'])) {
    $success_message = $_SESSION['logout_message'];
    unset($_SESSION['logout_message']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (!empty($username) && !empty($password)) {
        try {
            // HANYA SELECT KOLOM YANG ADA - HAPUS 'role'
            $stmt = $conn->prepare("SELECT id, username, password FROM login_event WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                
                // Verifikasi password
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['logged_in'] = true;
                    $_SESSION['role'] = 'user'; // Default role
                    
                    // Redirect ke halaman reminder.php
                    header("Location: reminder.php");
                    exit();
                } else {
                    $error = "Password salah!";
                }
            } else {
                $error = "Username tidak ditemukan!";
            }
            $stmt->close();
        } catch (Exception $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
            error_log("Login error: " . $e->getMessage());
        }
    } else {
        $error = "Username dan password harus diisi!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>Login - Reqra WhatsApp</title>
    <link rel="icon" type="image/png" href="LOGOJWD.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        /* Base mobile-first styles */
        * {
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #000000;
            min-height: 100vh;
            min-height: -webkit-fill-available;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            margin: 0;
            position: relative;
            overflow: hidden;
        }

        /* Background pattern for desktop */
        @media (min-width: 1024px) {
            body::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: 
                    radial-gradient(circle at 25% 25%, rgba(255,255,255,0.05) 0%, transparent 50%),
                    radial-gradient(circle at 75% 75%, rgba(255,255,255,0.05) 0%, transparent 50%);
                pointer-events: none;
            }
        }
        
        .login-container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
            position: relative;
            z-index: 10;
        }

        @media (min-width: 1024px) {
            .login-container {
                grid-template-columns: 1fr 1fr;
                align-items: center;
                gap: 4rem;
            }
        }
        
        .login-card {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            border-radius: 1.5rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
            overflow: hidden;
            width: 100%;
            max-width: 440px;
            margin: 0 auto;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
        }

        @media (min-width: 1024px) {
            .login-card {
                max-width: 440px;
                margin: 0;
                justify-self: end;
            }
        }

        @media (min-width: 1280px) {
            .login-card {
                max-width: 480px;
                transform: scale(1.05);
            }
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #374151 0%, #1f2937 100%);
            position: relative;
            overflow: hidden;
        }

        .gradient-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        @keyframes shine {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }
        
        .btn-primary { 
            background: linear-gradient(135deg, #4b5563 0%, #374151 100%);
            min-height: 56px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
            color: white;
        }
        
        .btn-primary:hover { 
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(75, 85, 99, 0.4);
            background: linear-gradient(135deg, #374151 0%, #4b5563 100%);
        }

        .btn-primary:active {
            transform: translateY(0);
        }
        
        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .input-focus {
            font-size: 16px;
            min-height: 56px;
            transition: all 0.3s ease;
            -webkit-appearance: none;
            border-radius: 12px;
            border: 2px solid #cbd5e1;
            background: #ffffff;
            padding: 0 1.25rem;
            font-weight: 500;
            color: #1f2937;
        }
        
        .input-focus:focus {
            border-color: #4b5563;
            box-shadow: 0 0 0 3px rgba(75, 85, 99, 0.1);
            outline: none;
            background: white;
            transform: translateY(-1px);
        }

        /* Hero Section for Desktop */
        .hero-section {
            display: none;
        }

        @media (min-width: 1024px) {
            .hero-section {
                display: block;
                color: white;
                text-align: left;
                padding: 2rem;
            }

            .hero-content {
                max-width: 500px;
            }

            .hero-title {
                font-size: 3.5rem;
                font-weight: 800;
                line-height: 1.1;
                margin-bottom: 1.5rem;
                background: linear-gradient(135deg, #e5e7eb 0%, #9ca3af 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .hero-subtitle {
                font-size: 1.25rem;
                margin-bottom: 2rem;
                opacity: 0.9;
                line-height: 1.6;
                color: #d1d5db;
            }

            .features-grid {
                display: grid;
                grid-template-columns: 1fr;
                gap: 1rem;
                margin-top: 2rem;
            }

            .feature-item {
                display: flex;
                align-items: center;
                gap: 0.75rem;
                padding: 1rem;
                background: rgba(255,255,255,0.1);
                border-radius: 12px;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255,255,255,0.2);
                transition: all 0.3s ease;
            }

            .feature-item:hover {
                background: rgba(255,255,255,0.15);
                transform: translateY(-2px);
            }

            .feature-icon {
                width: 40px;
                height: 40px;
                background: rgba(255,255,255,0.2);
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            
            .feature-text {
                flex: 1;
            }
            
            .feature-title {
                font-weight: 600;
                font-size: 0.95rem;
                margin-bottom: 0.25rem;
            }
            
            .feature-desc {
                font-size: 0.8rem;
                opacity: 0.9;
            }
        }

        @media (min-width: 1280px) {
            .hero-title {
                font-size: 4rem;
            }
            
            .hero-subtitle {
                font-size: 1.5rem;
            }
        }
        
        /* Enhanced mobile optimizations */
        @media (max-width: 480px) {
            body {
                padding: 0.5rem;
                align-items: flex-start;
                padding-top: 1rem;
                min-height: 100vh;
                background: #000000;
            }
            
            .login-card {
                border-radius: 1rem;
                margin: 0;
                max-width: 100%;
                box-shadow: 0 15px 30px rgba(0,0,0,0.3);
            }
            
            .mobile-p-6 {
                padding: 1.5rem;
            }
            
            .mobile-text-lg {
                font-size: 1.25rem;
            }
            
            .mobile-text-sm {
                font-size: 0.875rem;
            }
            
            .mobile-space-y-4 > * + * {
                margin-top: 1rem;
            }
            
            .mobile-flex-col {
                flex-direction: column;
            }
            
            .mobile-text-center {
                text-align: center;
            }
            
            /* Improved touch targets */
            .btn-primary {
                min-height: 52px;
            }
            
            .input-focus {
                min-height: 52px;
                padding: 0.75rem 1rem;
            }
        }
        
        @media (max-width: 360px) {
            .mobile-p-4 {
                padding: 1rem;
            }
            
            .mobile-text-md {
                font-size: 1.125rem;
            }
            
            .login-card {
                border-radius: 0.75rem;
            }
        }
        
        /* Tablet optimizations */
        @media (min-width: 481px) and (max-width: 1023px) {
            .login-card {
                max-width: 400px;
            }
            
            body {
                padding: 2rem;
            }
        }
        
        /* Landscape mode optimization */
        @media (max-height: 500px) and (orientation: landscape) {
            body {
                align-items: flex-start;
                padding-top: 1rem;
                padding-bottom: 1rem;
            }
            
            .login-card {
                max-height: 90vh;
                overflow-y: auto;
            }
            
            .gradient-bg {
                padding: 1rem !important;
            }
            
            .mobile-p-6 {
                padding: 1rem !important;
            }
        }
        
        /* High DPI screens */
        @media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
            .login-card {
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            }
        }
        
        /* Reduced motion for accessibility */
        @media (prefers-reduced-motion: reduce) {
            .btn-primary,
            .input-focus,
            .login-card,
            .feature-item,
            .gradient-bg::before {
                transition: none;
                animation: none;
            }
        }
        
        /* Dark mode support */
        @media (prefers-color-scheme: dark) {
            .login-card {
                background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
                color: #f9fafb;
            }
            
            .input-focus {
                background: #374151;
                border-color: #4b5563;
                color: #f9fafb;
            }
            
            .input-focus::placeholder {
                color: #9ca3af;
            }
        }
        
        /* Loading animation */
        .loading {
            display: inline-block;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Enhanced touch feedback */
        .touch-feedback:active {
            transform: scale(0.98);
        }
        
        /* Improved focus states for accessibility */
        .btn-primary:focus-visible {
            outline: 2px solid #4b5563;
            outline-offset: 2px;
        }
        
        .input-focus:focus-visible {
            outline: 2px solid #4b5563;
            outline-offset: 2px;
        }
        
        /* Better error/success message styling */
        .alert-message {
            border-radius: 12px;
            padding: 1rem 1.25rem;
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            backdrop-filter: blur(10px);
        }
        
        .alert-error {
            background-color: #fef2f2;
            border: 2px solid #fecaca;
            color: #dc2626;
        }
        
        .alert-success {
            background-color: #f0fdf4;
            border: 2px solid #bbf7d0;
            color: #16a34a;
        }
        
        /* Improved form spacing */
        .form-container {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        /* Better label styling */
        .form-label {
            display: flex;
            align-items: center;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #374151;
            font-size: 0.95rem;
        }

        /* Desktop enhanced elements */
        .desktop-feature {
            display: none;
        }
        
        @media (min-width: 768px) {
            .desktop-feature {
                display: block;
            }
        }

        /* Security badge */
        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1rem;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            margin-top: 1.5rem;
            font-size: 0.875rem;
            color: #64748b;
        }
    </style>
</head>
<body class="bg-black">
    <div class="login-container">
        <!-- Hero Section for Desktop -->
        <div class="hero-section">
            <div class="hero-content">
                <h1 class="hero-title">
                    Reqra
                    <br>
                    <span style="font-size: 2.5rem;">Business Solution</span>
                </h1>
                <p class="hero-subtitle">
                    Platform otomasi WhatsApp terintegrasi untuk mengoptimalkan komunikasi bisnis dan meningkatkan efisiensi operasional.
                </p>
                
                <div class="features-grid">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-bell text-white"></i>
                        </div>
                        <div class="feature-text">
                            <div class="feature-title">Reminder Pembayaran</div>
                            <div class="feature-desc">Otomatisasi pengingat jatuh tempo</div>
                        </div>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-bullhorn text-white"></i>
                        </div>
                        <div class="feature-text">
                            <div class="feature-title">Promosi & Marketing</div>
                            <div class="feature-desc">Promosi personal dan broadcast ke grup WhatsApp</div>
                        </div>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-chart-line text-white"></i>
                        </div>
                        <div class="feature-text">
                            <div class="feature-title">Analisis Chat Masuk</div>
                            <div class="feature-desc">Dashboard analitik dan tracking performa komunikasi</div>
                        </div>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-file-import text-white"></i>
                        </div>
                        <div class="feature-text">
                            <div class="feature-title">Integrasi Data</div>
                            <div class="feature-desc">Import dari Google Spreadsheet & pengiriman massal</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Login Card -->
        <div class="login-card">
            <!-- Header -->
            <div class="gradient-bg text-white p-8 mobile-text-center">
                <div class="flex justify-center items-center space-x-4 mb-4 mobile-flex-col mobile-space-y-4 relative z-10">
                    <div class="bg-white bg-opacity-20 p-4 rounded-2xl">
                        <i class="fas fa-comments text-white text-3xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold mobile-text-md">Reqra WhatsApp</h1>
                        <p class="text-gray-300 mt-2 text-sm mobile-text-sm">Sistem Pengiriman Pesan Otomatis</p>
                    </div>
                </div>
            </div>

            <!-- Login Form -->
            <div class="p-8 mobile-p-6">
                <?php if ($error): ?>
                    <div class="mb-6 alert-message alert-error">
                        <i class="fas fa-exclamation-circle mt-0.5 flex-shrink-0"></i>
                        <span class="text-sm"><?= htmlspecialchars($error) ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($success_message): ?>
                    <div class="mb-6 alert-message alert-success">
                        <i class="fas fa-check-circle mt-0.5 flex-shrink-0"></i>
                        <span class="text-sm"><?= htmlspecialchars($success_message) ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="form-container">
                    <div>
                        <label class="form-label text-gray-700 mobile-text-sm">
                            <i class="fas fa-user mr-2 text-gray-500"></i>Username
                        </label>
                        <input 
                            type="text" 
                            name="username" 
                            required 
                            class="w-full px-4 py-4 border border-gray-300 rounded-lg focus:outline-none input-focus touch-feedback"
                            placeholder="Masukkan username Anda"
                            value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                            autocapitalize="none"
                            autocorrect="off"
                            spellcheck="false"
                            autocomplete="username"
                        >
                    </div>

                    <div>
                        <label class="form-label text-gray-700 mobile-text-sm">
                            <i class="fas fa-lock mr-2 text-gray-500"></i>Password
                        </label>
                        <input 
                            type="password" 
                            name="password" 
                            required 
                            class="w-full px-4 py-4 border border-gray-300 rounded-lg focus:outline-none input-focus touch-feedback"
                            placeholder="Masukkan password Anda"
                            autocapitalize="none"
                            autocorrect="off"
                            spellcheck="false"
                            autocomplete="current-password"
                        >
                    </div>

                    <!-- Desktop enhanced features -->
                    <div class="desktop-feature flex items-center justify-between text-sm">
                        <label class="flex items-center">
                            <input type="checkbox" class="mr-2 rounded border-gray-300">
                            <span class="text-gray-600">Ingat saya</span>
                        </label>
                        <a href="#" class="text-gray-700 hover:text-gray-900 transition-colors">
                            Lupa password?
                        </a>
                    </div>

                    <button 
                        type="submit" 
                        class="w-full btn-primary text-white py-4 rounded-lg font-semibold text-base md:text-lg transition duration-300 flex items-center justify-center touch-feedback"
                        id="login-button"
                    >
                        <i class="fas fa-sign-in-alt mr-3"></i>
                        <span id="login-text">Masuk ke Sistem</span>
                    </button>
                </form>

                <!-- Security Badge -->
                <div class="security-badge">
                    <i class="fas fa-shield-alt text-green-500"></i>
                    <span>Sistem terenkripsi dengan keamanan tinggi</span>
                </div>

                <!-- Additional Info -->
                <div class="mt-6 pt-6 border-t border-gray-200">
                    <div class="text-center text-gray-600 mobile-text-sm">
                        <p class="text-xs text-gray-500">
                            Sistem WhatsApp Reminder - Reqra &copy; 2025
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Enhanced mobile-friendly interactions
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const loginButton = document.getElementById('login-button');
            const loginText = document.getElementById('login-text');
            const inputs = document.querySelectorAll('input');
            
            // Prevent form resubmission
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.href);
            }
            
            // Enhanced input focus effects
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('ring-2', 'ring-gray-500', 'ring-opacity-20');
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('ring-2', 'ring-gray-500', 'ring-opacity-20');
                });
                
                // Clear error when user starts typing
                input.addEventListener('input', function() {
                    const errorDiv = document.querySelector('.alert-error');
                    if (errorDiv) {
                        errorDiv.style.display = 'none';
                    }
                });
            });
            
            // Enhanced form submission with better loading state
            form.addEventListener('submit', function(e) {
                const buttonIcon = loginButton.querySelector('i');
                const originalIcon = buttonIcon.className;
                
                // Show loading state
                loginButton.disabled = true;
                buttonIcon.className = 'fas fa-spinner loading mr-3';
                loginText.textContent = 'Memproses...';
                
                // Add slight delay for better UX
                setTimeout(() => {
                    // Form will submit normally
                }, 100);
            });
            
            // Handle orientation changes
            window.addEventListener('orientationchange', function() {
                // Small delay to ensure CSS has applied
                setTimeout(() => {
                    window.scrollTo(0, 0);
                }, 100);
            });
            
            // Enhanced touch feedback for all interactive elements
            const interactiveElements = document.querySelectorAll('button, input, a');
            interactiveElements.forEach(el => {
                el.addEventListener('touchstart', function() {
                    this.classList.add('touch-feedback');
                });
                
                el.addEventListener('touchend', function() {
                    this.classList.remove('touch-feedback');
                });
            });
            
            // Auto-focus username field on load (except on mobile to prevent keyboard popup)
            if (window.innerWidth > 768) {
                setTimeout(() => {
                    inputs[0].focus();
                }, 500);
            }
            
            // Desktop specific enhancements
            if (window.innerWidth >= 1024) {
                // Add parallax effect to background
                document.addEventListener('mousemove', function(e) {
                    const moveX = (e.clientX - window.innerWidth / 2) * 0.01;
                    const moveY = (e.clientY - window.innerHeight / 2) * 0.01;
                    document.body.style.backgroundPosition = `${50 + moveX}% ${50 + moveY}%`;
                });

                // Add smooth entrance animation
                const loginCard = document.querySelector('.login-card');
                const heroSection = document.querySelector('.hero-section');
                
                loginCard.style.opacity = '0';
                loginCard.style.transform = 'translateX(50px)';
                heroSection.style.opacity = '0';
                heroSection.style.transform = 'translateX(-50px)';
                
                setTimeout(() => {
                    loginCard.style.transition = 'all 0.6s ease-out';
                    heroSection.style.transition = 'all 0.6s ease-out';
                    loginCard.style.opacity = '1';
                    loginCard.style.transform = 'translateX(0)';
                    heroSection.style.opacity = '1';
                    heroSection.style.transform = 'translateX(0)';
                }, 200);
            }
        });
    </script>
</body>
</html>